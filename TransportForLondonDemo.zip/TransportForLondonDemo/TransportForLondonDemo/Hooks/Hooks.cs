﻿using BoDi;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using TechTalk.SpecFlow.Assist.ValueRetrievers;
using TransportForLondonDemo.Actors;
using TransportForLondonDemo.Screens;

namespace TransportForLondonDemo.Hooks
{
    [Binding]
    public sealed class Hooks
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        private readonly ScenarioContext _scenarioContext;

        public Hooks(IObjectContainer objectContainer, ScenarioContext scenarioContext)
        {
            this._scenarioContext = scenarioContext;
            objectContainer.RegisterInstanceAs(new AppElements());
        }

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            Service.Instance.ValueRetrievers.Register(new DateTimeValueRetriever());
        }

        [BeforeScenario]
        public static void BeforeScenario()
        {
        }

        [AfterScenario]
        public static void CleanUp()
        {
            PagesBase.CloseApplication();
        }
    }
}
