﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TransportForLondonDemo.Hooks
{
    [Binding]
    public class CustomTransforms
    {
        [StepArgumentTransformation(@"(\d+) days in the future")]
        public DateTime DaysInTheFuture(int days)
        {
            return DateTime.Today.AddDays(days);
        }
    }
}
