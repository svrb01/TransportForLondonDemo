﻿using OpenQA.Selenium;
using System;
using System.Threading;
using TransportForLondonDemo.Actors;
using TransportForLondonDemo.Screens;

namespace TransportForLondonDemo.Actions
{
    public static class JourneyResultsInteractions
    {
        public static void ClickOnEditJourneyButton(this IActorInteractionsContext<AppElements> ctx)
        {
            ctx.Elements.JourneyResults.EditJourneyButton.Click();
        }

        public static void ClickOnUpdateJourneyButton(this IActorInteractionsContext<AppElements> ctx)
        {
            ctx.Elements.JourneyResults.UpdateJourneyButton.Click();
        }

        public static void EditJourneyDateTime(this IActorInteractionsContext<AppElements> ctx, DateTime dateTime, DateTime time, string journeyType)
        {
            PagesBase.EditJourneyDateTime(dateTime, time, journeyType);
        }

    }
}
