﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransportForLondonDemo.Actors;
using FluentAssertions;
using System.Threading;

namespace TransportForLondonDemo.Actions
{
    public static class JourneyPlannerExpectations
    {
        public static void PlanAJourneyPageIsDisplayed(this IActorExpectationsContext<AppElements> ctx)
        {
            Thread.Sleep(2000);
            ctx.Elements.JourneyPlanner.PlanJourneyTitle.Text.Should().BeEquivalentTo("Plan a journey", "Plan a journey page should be displayed");
        }

        public static void ListOfRecentJourneysIsDisplayed(this IActorExpectationsContext<AppElements> ctx)
        {
            Thread.Sleep(2000);
            ctx.Elements.JourneyPlanner.RecentJourneyList.Count.Should().BeGreaterThan(0, "List of recently journey results should be displayed");
        }

        public static void ValidationErrorInFromFieldIsDisplayed(this IActorExpectationsContext<AppElements> ctx, string errorText)
        {
            Thread.Sleep(2000);
            string c = ctx.Elements.JourneyPlanner.FromFieldValidationError.Text;
            ctx.Elements.JourneyPlanner.FromFieldValidationError.Text.Should().BeEquivalentTo(errorText, "Validation error text for From field should be displayed");
        }
        public static void ValidationErrorInToFieldIsDisplayed(this IActorExpectationsContext<AppElements> ctx, string errorText)
        {
            Thread.Sleep(2000);
            string c = ctx.Elements.JourneyPlanner.ToFieldValidationError.Text;

            ctx.Elements.JourneyPlanner.ToFieldValidationError.Text.Should().BeEquivalentTo(errorText, "Validation error text for To field should be displayed");
        }

    }
}
