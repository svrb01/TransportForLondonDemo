﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransportForLondonDemo.Actors;
using FluentAssertions;
using System.Threading;

namespace TransportForLondonDemo.Actions
{
    public static class JourneyResultsExpectations
    {
        public static void SeeJourneyResults(this IActorExpectationsContext<AppElements> ctx)
        {
            Thread.Sleep(2000);
            ctx.Elements.JourneyResults.JourneyResultsList.Count.Should().BeGreaterThan(0,"List of journey results should be displayed");
        }

        public static void SeeJourneyResultsMessage(this IActorExpectationsContext<AppElements> ctx,string messageText)
        {
            Thread.Sleep(2000);
            ctx.Elements.JourneyResults.ResultMessage.GetAttribute("textContent").Should().Contain(messageText, "journey results should be displayed");
        }

        public static void SeeJourneyResultsValidationErrorMessage(this IActorExpectationsContext<AppElements> ctx, string errorMessageText)
        {
            Thread.Sleep(2000);
            ctx.Elements.JourneyResults.ValidationError.GetAttribute("textContent").Should().Contain(errorMessageText, "Could not find matching criteria should be displayed");
        }

        public static void SeeRecentJourneyResults(this IActorExpectationsContext<AppElements> ctx)
        {
            Thread.Sleep(2000);
            ctx.Elements.JourneyResults.RecentJourneyResultsList.Count.Should().BeGreaterThan(0, "List of recent journey results should be displayed");
        }
    }
}
