﻿using OpenQA.Selenium;
using System;
using System.Threading;
using TransportForLondonDemo.Actors;
using TransportForLondonDemo.Screens;

namespace TransportForLondonDemo.Actions
{
    public static class JourneyPlannerInteractions
    {
        public static void NavigateToSite(this IActorInteractionsContext<AppElements> ctx)
        {
            PagesBase.InitStartApp();
            ctx.ClickOnAcceptAllCookiesButton();
        }

        public static void ClickOnPlanAJourneyTab(this IActorInteractionsContext<AppElements> ctx)
        {
            ctx.Elements.JourneyPlanner.PlanJourneyTab.Click();
        }

        public static void ClickOnRecentsTab(this IActorInteractionsContext<AppElements> ctx)
        {
            ctx.Elements.JourneyPlanner.RecentsTab.Click();
        }
        public static void ClickOnPlanMyJourneyButton(this IActorInteractionsContext<AppElements> ctx)
        {
            ctx.Elements.JourneyPlanner.PlanMyJourneyButton.Click();
        }

        public static void EnterValueInFrom(this IActorInteractionsContext<AppElements> ctx, string text)
        {
            ctx.Elements.JourneyPlanner.To.SendKeys(Keys.Control + "A");
            ctx.Elements.JourneyPlanner.To.SendKeys(Keys.Delete);
            ctx.Elements.JourneyPlanner.From.SendKeys(text);
            ctx.Elements.JourneyPlanner.From.SendKeys(Keys.Tab);
        }

        public static void EnterValueInTo(this IActorInteractionsContext<AppElements> ctx, string text)
        {
            ctx.Elements.JourneyPlanner.To.SendKeys(Keys.Control + "A");
            ctx.Elements.JourneyPlanner.To.SendKeys(Keys.Delete);
            ctx.Elements.JourneyPlanner.To.SendKeys(text);
            ctx.Elements.JourneyPlanner.From.SendKeys(Keys.Tab);
        }

        public static void ClickOnAcceptAllCookiesButton(this IActorInteractionsContext<AppElements> ctx)
        {
            PagesBase.AcceptCookieDialog();
        }

        public static void PlanDateTime(this IActorInteractionsContext<AppElements> ctx, DateTime dateTime, DateTime time,string journeyType)
        {
            PagesBase.PlanDateTime(dateTime,time, journeyType);
        }
    }
}
