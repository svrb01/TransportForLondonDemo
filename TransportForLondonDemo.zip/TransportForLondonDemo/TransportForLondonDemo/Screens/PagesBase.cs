﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransportForLondonDemo.Hooks;
using System.IO;

namespace TransportForLondonDemo.Screens
{
    public class PagesBase
    {
        public static IWebDriver _driver { get; private set; }
        public static void InitStartApp()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://tfl.gov.uk/");

            driver.Manage().Window.Maximize();
            var currentWindow = driver.CurrentWindowHandle;
            driver.SwitchTo().Window(currentWindow);
            _driver = driver;
        }

        public static void AcceptCookieDialog()
        {
            _driver.FindElement(By.Id("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll"),5).Click();
            _driver.FindElement(By.Id("cb-confirmedSettings")).FindElement(By.Id("cb-buttons")).FindElements(By.TagName("button"))[0].Click();
        }

        public static void SelectItems(IWebElement element, string text, bool partialMatch)
        {
            SelectElement oSelect = new SelectElement(element);
            oSelect.SelectByText(text, partialMatch);
        }

        public static string FormatDateTime(DateTime dateTime)
        {
            return dateTime.ToString("ddd dd MMM");
        }

        public static string FormatTime(DateTime dateTime)
        {
            return dateTime.ToString("HH:mm");
        }

        public static void PlanDateTime(DateTime dateTime, DateTime time, string journeyType = "leaving")
        {
            var date = FormatDateTime(dateTime);
            var _time = FormatTime(time);

            _driver.FindElement(By.LinkText("change time")).Click();

            var element = (journeyType=="arriving") ? _driver.FindElement(By.Id("arriving")) : _driver.FindElement(By.Id("departing"));
            element.Click();
            SelectItems(JourneyPlanner.Date, date, false);
            SelectItems(JourneyPlanner.Time, _time,false);
        }

        public static void EditJourneyDateTime(DateTime dateTime, DateTime time, string journeyType = "leaving")
        {
            var date = FormatDateTime(dateTime);
            var _time = FormatTime(time);

            var element = (journeyType == "arriving") ? _driver.FindElement(By.Id("arriving")) : _driver.FindElement(By.Id("departing"));
            element.Click();
            SelectItems(JourneyPlanner.Date, date, false);
            SelectItems(JourneyPlanner.Time, _time, false);
        }

        public static void CloseApplication()
        {
            _driver.Close();
        }

    }
}
