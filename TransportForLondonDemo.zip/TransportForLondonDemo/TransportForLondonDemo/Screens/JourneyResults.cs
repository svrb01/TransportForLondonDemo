﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransportForLondonDemo.Hooks;

namespace TransportForLondonDemo.Screens
{
    public class JourneyResults:PagesBase
    {
        public IWebElement JourneyResultsTitle => _driver.FindElement(By.ClassName("jp-results-headline"));
        public IWebElement EditJourneyButton => _driver.FindElement(By.ClassName("edit-journey"));
        
        public IWebElement ValidationError => _driver.FindElement(By.CssSelector("div[class='main results-wrapper publictransport']")).FindElement(By.ClassName("field-validation-error"));
        public IWebElement UpdateJourneyButton => _driver.FindElement(By.Id("plan-journey-button"));

        public IWebElement ResultMessage => _driver.FindElement(By.CssSelector("div[class='info-message disambiguation']"));
        public List<IWebElement> JourneyResultsList => _driver.FindElements(By.XPath("//*[@id='disambiguation-options-to']/li")).ToList();
        public List<IWebElement> RecentJourneyResultsList => _driver.FindElements(By.XPath("//*[@id='jp-recent-content-jp-']/a")).ToList();
       
    }
}
