﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using TransportForLondonDemo.Hooks;

namespace TransportForLondonDemo.Screens
{
    public class JourneyPlanner : PagesBase
    {
        public IWebElement PlanJourneyTitle => _driver.FindElement(By.ClassName("headline-container"));

        public IWebElement From => _driver.FindElement(By.Id("InputFrom"));

        public IWebElement To => _driver.FindElement(By.Id("InputTo"));

        public IWebElement ChangeTime => _driver.FindElement(By.LinkText("change time"));

        public IWebElement PlanMyJourneyButton => _driver.FindElement(By.Id("plan-journey-button"));

        public IWebElement RecentsTab => _driver.FindElement(By.LinkText("Recents"));

        public IWebElement PlanJourneyTab => _driver.FindElement(By.ClassName("plan-journey")).FindElement(By.LinkText("Plan a journey"));

        public List<IWebElement> RecentJourneyList => _driver.FindElements(By.XPath("//*[@id='jp-recent-content-jp-']/a")).ToList();

        public IWebElement FromFieldValidationError => _driver.FindElement(By.ClassName("field-validation-error"),5).FindElement(By.Id("InputFrom-error"));
        public IWebElement ToFieldValidationError => _driver.FindElement(By.Id("InputTo-error"));

        public IWebElement FirstFromStopPoint => _driver.FindElement(By.Id("InputFrom"), 5).FindElement(By.Id("stop-points-search-suggestion-0"));
        public IWebElement FirstToStopPoint => _driver.FindElement(By.Id("InputTo"), 5).FindElement(By.Id("InputTo-dropdown")).FindElement(By.Id("stop-points-search-suggestion-0"));
        public static IWebElement Date => _driver.FindElement(By.Id("Date"));
        public static IWebElement Time => _driver.FindElement(By.Id("Time"));

    }
}
