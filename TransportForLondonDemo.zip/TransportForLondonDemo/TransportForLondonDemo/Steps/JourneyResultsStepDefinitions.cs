﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TransportForLondonDemo.Actions;
using TransportForLondonDemo.Actors;

namespace TransportForLondonDemo.Steps
{
    [Binding]
    public sealed class JourneyResultsStepDefinitions
    {
        private readonly Actor<AppElements> actor;

        public JourneyResultsStepDefinitions(Actor<AppElements> actor)
        {
            this.actor = actor;
        }

        [Then(@"I see journey results")]
        public void ThenISeeJourneyResults()
        {
            this.actor.ExpectsTo.SeeJourneyResults();
        }
        
        [When(@"I click on Edit journey button")]
        public void WhenIClickOnEditJourneyButton()
        {
            this.actor.AttemptsTo.ClickOnEditJourneyButton();
        }

        [When(@"I click on update journey button")]
        public void WhenIClickOnUpdateJourneyButton()
        {
            this.actor.AttemptsTo.ClickOnUpdateJourneyButton();
        }

        [Then(@"I see journey result update with message (.*)")]
        public void ThenISeeJourneyResultUpdateWithMessage(string messageText)
        {
            this.actor.ExpectsTo.SeeJourneyResultsMessage(messageText);
        }

        [When(@"I edit (.*) date to be (.* days in the future) and time to be (.*)")]
        public void WhenIEditLeavingDateToBeDaysInTheFutureAndTimeToBe(string journeyType, DateTime dateTime, DateTime time)
        {
            this.actor.AttemptsTo.EditJourneyDateTime(dateTime, time, journeyType);
        }

        [Then(@"I see validation error text (.*)")]
        public void ThenISeeValidationErrorText(string errorText)
        {
            this.actor.ExpectsTo.SeeJourneyResultsValidationErrorMessage(errorText);
        }

    }
}
