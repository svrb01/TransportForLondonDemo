﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TransportForLondonDemo.Actions;
using TransportForLondonDemo.Actors;

namespace TransportForLondonDemo.Steps
{
    [Binding]
    public sealed class JourneyPlannerStepDefinitions
    {
        private readonly Actor<AppElements> actor;

        public JourneyPlannerStepDefinitions(Actor<AppElements> actor)
        {
            this.actor = actor;
        }

        [Given(@"I access the transport for london website")]
        public void GivenIAccessTheTransportForLondonWebsite()
        {
            this.actor.AttemptsTo.NavigateToSite();
        }

        [When(@"I click on Plan a journey tab")]
        public void WhenIClickOnPlanAJourneyTab()
        {
            this.actor.AttemptsTo.ClickOnPlanAJourneyTab();
        }

        [Then(@"I see Plan a journey page")]
        public void ThenISeePlanAJourneyPage()
        {
            this.actor.ExpectsTo.PlanAJourneyPageIsDisplayed();
        }

        [When(@"I enter a valid place (.*) in from field")]
        public void WhenIEnterAValidPlaceInFromField(string place)
        {
            this.actor.AttemptsTo.EnterValueInFrom(place);
        }

        [When(@"I enter a valid place (.*) in to field")]
        public void WhenIEnterAValidPlaceInToField(string place)
        {
            this.actor.AttemptsTo.EnterValueInTo(place);
        }

        [When(@"I plan a (.*) date to be (.* days in the future) and time to be (.*)")]
        public void WhenIPlanALeavingTimeToBeNow(string journeyType, DateTime dateTime, DateTime time)
        {
            this.actor.AttemptsTo.PlanDateTime(dateTime, time, journeyType);
        }

        [When(@"I click on Plan my journey button")]
        public void WhenIClickOnPlanMyJourneyButton()
        {
            this.actor.AttemptsTo.ClickOnPlanMyJourneyButton();
        }

        [When(@"I click on the Recents tab")]
        public void WhenIClickOnTheRecentsTab()
        {
            this.actor.AttemptsTo.ClickOnRecentsTab();
        }

        [Then(@"I see recently planned journey results")]
        public void ThenISeeRecentlyPlannedJourneyResults()
        {
            this.actor.ExpectsTo.SeeRecentJourneyResults();
        }

        [Then(@"I see From field displaying validation error text (.*)")]
        public void ThenISeeFromFieldDisplayingValidationErrorText(string errorText)
        {
            this.actor.ExpectsTo.ValidationErrorInFromFieldIsDisplayed(errorText);
        }

        [Then(@"I see To field displaying validation error text The (.*)")]
        public void ThenISeeToFieldDisplayingValidationErrorText(string errorText)
        {
            this.actor.ExpectsTo.ValidationErrorInToFieldIsDisplayed(errorText);
        }

    }
}
