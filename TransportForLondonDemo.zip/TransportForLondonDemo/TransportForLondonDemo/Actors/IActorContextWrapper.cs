﻿namespace TransportForLondonDemo.Actors
{
    public interface IActorContextWrapper<T> :
        IActorInteractionsContext<T>,
        IActorExpectationsContext<T> where T : AppElements
    {
    }
}
