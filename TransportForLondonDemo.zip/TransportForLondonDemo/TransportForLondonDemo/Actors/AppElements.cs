﻿using TransportForLondonDemo.Screens;

namespace TransportForLondonDemo.Actors
{
    public class AppElements
    {
        public AppElements()
        {
            this.JourneyPlanner = new JourneyPlanner();
            this.JourneyResults = new JourneyResults();
        }

        public JourneyPlanner JourneyPlanner { get; }
        public JourneyResults JourneyResults { get; }
    }
}
